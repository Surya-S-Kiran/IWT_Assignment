function square(a) {
	return a*a;
}

function check() {
/*	let matrix = new Array(4);
	for(let i=0; i < matrix.length; i++)
		matrix[i] = new Array(4);

	let v = 1;
	for(i=0; i < matrix.length; i++) {
		for(j=0; j < matrix[i].length; j++)
			matrix[i][j] = v++;
	}

	for(let i=0; i < matrix.length; i++) {
		row = "";
		for(let j=0; j < matrix[i].length; j++) {
			row += matrix[i][j] + ' ';
		}
		console.log(row);
	}
*/
	console.log(square(4)); 
}